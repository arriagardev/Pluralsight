﻿Imports System.IO

Module Module1

    Sub Main()
        OpenFile1()
        Console.ReadKey()
    End Sub

    Sub OpenFile1()
        Dim fs As New FileStream("C:\file.docx", FileMode.Open)
    End Sub

    Sub OpenFile2()
        Dim fs As FileStream = Nothing
        Try
            fs = New FileStream("C:\file.docx", FileMode.Open)
            ' ...
        Finally
            If fs IsNot Nothing Then
                fs.Dispose()
            End If
        End Try
    End Sub

    Sub OpenFile3()
        Using fs As New FileStream("C:\file.docx", FileMode.Open)
            ' ...
        End Using
    End Sub

End Module
