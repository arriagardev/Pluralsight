﻿Module Module1

    Sub Main()
        Dim math As New MathLib.Math()
        Dim result = math.Add(10, 20)
        Console.WriteLine(result)
    End Sub

End Module
