﻿Imports System.Threading.Tasks

Module Module1

    Sub Main()
        Dim nums(499) As Integer
        For index = 0 To nums.Length - 1
            nums(index) = index
        Next

        Parallel.ForEach(nums, _
            Sub(num) Console.WriteLine(num))
    End Sub

End Module
