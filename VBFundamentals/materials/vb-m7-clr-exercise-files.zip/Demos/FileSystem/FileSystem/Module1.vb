﻿Module Module1

    Sub Main()
        Dim fileSystem = My.Computer.FileSystem

        Dim docsFilePath = fileSystem.SpecialDirectories.MyDocuments
        Dim docsFolder = fileSystem.GetDirectoryInfo(docsFilePath)

        For Each folder In docsFolder.GetDirectories()
            Console.WriteLine(folder.Name)

            For Each file In folder.GetFiles()
                Console.WriteLine(vbTab & file.Name)
            Next
        Next

        Dim demoFilePath = docsFilePath & "\Demo Documents\Lorem Impsum.txt"
        If fileSystem.FileExists(demoFilePath) Then
            Dim contents = fileSystem.ReadAllText(demoFilePath)
            Console.WriteLine()
            Console.WriteLine(contents)
        End If

    End Sub

End Module

