﻿Module Module1

    Sub Main()
        Dim name As String = "Rob"
        Dim name2 As String
        name2 = "Rob"
        name2 = "Scott"

        Dim age As Integer = 25
        Dim ofAge As Boolean = _
            age >= 21
    End Sub

End Module
