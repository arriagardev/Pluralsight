﻿Module Module1

    Sub Main()
        Console.WriteLine("Hello, World!")
        Console.ReadKey()
    End Sub

End Module
