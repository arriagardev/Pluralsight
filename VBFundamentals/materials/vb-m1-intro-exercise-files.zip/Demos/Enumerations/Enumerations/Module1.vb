﻿Module Module1

    Enum Suits
        Clubs = 10
        Hearts
        Diamonds
        Spades
    End Enum

    Sub Main()
        Dim suit As Suits = Suits.Clubs
    End Sub

End Module
