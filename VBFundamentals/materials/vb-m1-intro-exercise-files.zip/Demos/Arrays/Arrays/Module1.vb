﻿Module Module1

    Sub Main()
        Dim nums(2) As Integer
        nums(0) = 10
        nums(1) = 20
        nums(2) = 30

        Dim nums2() As Integer = {10, 20, 30}

        Dim grid = {{1, 2}, {3, 4}}
    End Sub

End Module
