﻿Module Module1

    Private _rand As New Random()

    Sub Main()
        ' Query()
        QueryWithLambdas()
    End Sub

    Private Function MakeList() As List(Of Employee)
        Dim employees As New List(Of Employee)
        For i = 1 To 100
            Dim day = _rand.Next(1, 28)
            Dim month = _rand.Next(1, 12)
            Dim year = _rand.Next(1950, 1990)
            Dim birthDate = New DateTime(year, month, day)

            Dim emp As New Employee("Employee" & i, i Mod 2 = 0, birthDate)
            employees.Add(emp)
        Next
        Return employees
    End Function

    Private Sub Query()
        Dim employees = MakeList()
        Dim query = From emp In employees
                    Where emp.Salaried AndAlso emp.Age > 35
                    Select emp

        For Each emp In query
            Console.WriteLine(emp.GetDescription())
        Next
    End Sub

    Private Sub QueryWithLambdas()
        Dim employees = MakeList()

        Dim query = employees.Where( _
            Function(e) e.Salaried AndAlso e.Age > 35)

        For Each emp In query
            Console.WriteLine(emp.GetDescription())
        Next
    End Sub

End Module
