﻿Option Strict On

Module Module1

    Sub Main()
        ' SquareList()
        ' ShapeList()
        MixedList()
    End Sub

    Private Sub SquareList()
        Dim squares As New List(Of Square)
        For i = 1 To 10
            Dim square As New Square(10)
            square.Name = "Square" & i
            squares.Add(square)
        Next

        For Each square In squares
            Console.WriteLine(square.Name)
        Next
    End Sub

    Private Sub ShapeList()
        Dim shapes As New List(Of Shape)
        For i = 1 To 10
            Dim shape As Shape
            If i Mod 2 = 0 Then
                shape = New Square(10)
            Else
                shape = New Circle(10)
            End If
            shape.Name = "Shape" & i
            shapes.Add(shape)
        Next

        For Each shape In shapes
            Console.WriteLine(shape.Name)
        Next
    End Sub

    Private Sub MixedList()
        ' Dim things As New List(Of Object)
        Dim things As New ArrayList()
        For i = 1 To 10
            Dim thing As Object
            If i Mod 2 = 0 Then
                Dim emp As New Employee()
                emp.Name = "Employee" & i
                thing = emp
            Else
                Dim square As New Square(10)
                square.Name = "Square" & i
                thing = square
            End If
            things.Add(thing)
        Next

        For Each thing In things
            ' Option Strict Off - Late Binding
            ' Console.WriteLine(thing.Name)

            ' Option Strict On - Early Binding
            If TypeOf thing Is Employee Then
                Dim emp = CType(thing, Employee)
                Console.WriteLine(emp.Name)
            ElseIf TypeOf thing Is Square Then
                Dim square = CType(thing, Square)
                Console.WriteLine(square.Name)
            End If
        Next
    End Sub

End Module

