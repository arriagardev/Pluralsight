﻿Option Strict On

Module Module1

    Private _rand As New Random()

    Sub Main()
        ' SquareDictionary()
        ' ShapeDictionary()
        MixedDictionary()
    End Sub

    Private Sub SquareDictionary()
        Dim squares As New Dictionary(Of Integer, Square)
        For i = 1 To 10
            Dim id As Integer = i * i
            Dim item As New Square(10)
            item.ID = id
            item.Name = "Square" & i

            If Not squares.ContainsKey(id) Then
                squares.Add(id, item)
            End If
        Next

        Dim key = _rand.Next(1, 10)
        key = key * key
        If squares.ContainsKey(key) Then
            Dim square = squares(key)
            Console.WriteLine("The item with key {0} is {1}", _
                key, square.Name)
        End If
    End Sub

    Private Sub ShapeDictionary()
        Dim shapes As New Dictionary(Of Integer, Shape)
        For i = 1 To 10
            Dim id As Integer = i * i
            Dim item As Shape
            If i Mod 2 = 0 Then
                item = New Square(10)
                item.Name = "Square" & i
            Else
                item = New Circle(10)
                item.Name = "Circle" & i
            End If
            item.ID = id
            If Not shapes.ContainsKey(id) Then
                shapes.Add(id, item)
            End If
        Next

        Dim key = _rand.Next(1, 10)
        key = key * key
        If shapes.ContainsKey(key) Then
            Dim shape = shapes(key)
            Console.WriteLine("The item with key {0} is {1}", key, shape.Name)
        End If
    End Sub

    Private Sub MixedDictionary()
        ' Dim things As New Dictionary(Of Integer, Object)
        Dim things As New Hashtable()
        For i = 1 To 10
            Dim id As Integer = i * i
            Dim thing As Object
            If i Mod 2 = 0 Then
                Dim emp As New Employee()
                emp.ID = id
                emp.Name = "Employee" & i
                thing = emp
            Else
                Dim square As New Square(10)
                square.ID = id
                square.Name = "Square" & i
                thing = square
            End If
            If Not things.ContainsKey(id) Then
                things.Add(id, thing)
            End If
        Next

        Dim key = _rand.Next(1, 10)
        key = key * key

        If things.ContainsKey(key) Then
            Dim thing = things(key)

            ' Option Strict Off - Late Binding
            ' Console.WriteLine("The item with key {0} is {1}", index, thing.Name)

            ' Option Strict On - Early Binding
            If TypeOf thing Is Employee Then
                Dim emp = CType(thing, Employee)
                Console.WriteLine("The item with key {0} is {1}", key, emp.Name)
            ElseIf TypeOf thing Is Square Then
                Dim square = CType(thing, Square)
                Console.WriteLine("The item with key {0} is {1}", key, square.Name)
            End If
        End If
    End Sub
End Module

