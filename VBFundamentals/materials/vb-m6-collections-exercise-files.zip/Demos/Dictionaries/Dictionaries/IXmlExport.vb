﻿Public Interface IXmlExport
    Function GetXml() As String
End Interface
