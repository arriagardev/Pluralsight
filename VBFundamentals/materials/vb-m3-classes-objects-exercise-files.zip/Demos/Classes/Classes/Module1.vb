﻿Module Module1

    Sub Main()
        Dim e1 As New Employee("Rob", False)
        Dim e2 As New Employee()
        e2.Name = "Scott"
        e2.Salaried = True
        Dim e3 As New Employee() With {.Name = "Julie"}

        Console.WriteLine(e1.GetDescription())
        Console.WriteLine(e2.GetDescription())
        Console.WriteLine(e3.GetDescription())
    End Sub

End Module
