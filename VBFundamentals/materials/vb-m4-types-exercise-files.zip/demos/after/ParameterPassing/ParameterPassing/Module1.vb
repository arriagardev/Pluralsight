﻿Module Module1

    Sub Main()
        Dim y As Integer = 5
        Foo(y)
        Console.WriteLine(y)

        Dim emp As New Employee("Rob", False)
        Bar(emp)
        Console.WriteLine(emp.Name)

        Dim y2 As Integer = 5
        Foo2(y2)
        Console.WriteLine(y2)

        Dim emp2 As New Employee("Rob", False)
        Bar2(emp2)
        Console.WriteLine(emp2.Name)
    End Sub

    Sub Foo(ByVal x As Integer)
        x += 5
    End Sub

    Sub Foo2(ByRef x As Integer)
        x += 5
    End Sub

    Sub Bar(emp As Employee)
        ' emp.Name = "Scott"
        emp = New Employee("Kate", True)
    End Sub

    Sub Bar2(ByRef emp As Employee)
        ' emp.Name = "Scott"
        emp = New Employee("Kate", True)
    End Sub

End Module
