﻿Imports System.Net
Imports System.IO

Module Module1

    Sub Main()
        Dim request = WebRequest.Create("http://www.pluralsight.com")
        Dim response = request.GetResponse()
        Dim reader As New StreamReader(response.GetResponseStream())
        Console.WriteLine(reader.ReadToEnd())
    End Sub

End Module
