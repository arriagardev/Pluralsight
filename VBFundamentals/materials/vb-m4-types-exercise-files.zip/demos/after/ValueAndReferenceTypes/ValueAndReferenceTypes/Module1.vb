﻿Module Module1

    Sub Main()
        ValueTypes()
        ReferenceTypes()
        Strings()
    End Sub

    Sub ValueTypes()
        Dim x As Integer = 5
        Dim y As Integer
        y = x
        x = 10
        Console.WriteLine(x)
        Console.WriteLine(y)
    End Sub

    Sub ReferenceTypes()
        Dim e1 As New Employee("Scott", True)
        Dim e2 As Employee = e1
        Dim e3 As New Employee("Rob", False)
        Dim e4 As Employee = Nothing

        Console.WriteLine(e1.GetDescription())
        Console.WriteLine(e2.GetDescription())
        Console.WriteLine(e3.GetDescription())
        Console.WriteLine(If(e4 Is Nothing, "Nothing", _
            e4.GetDescription()))
    End Sub

    Sub Strings()
        Dim s1 As String = "Scott"
        Dim s2 As String = s1

        s2 = "Rob"
        Dim s3 As String

        Console.WriteLine(s1)
        Console.WriteLine(s2)
        Console.WriteLine(If(s3 Is Nothing, "Nothing", s3))
    End Sub

End Module
