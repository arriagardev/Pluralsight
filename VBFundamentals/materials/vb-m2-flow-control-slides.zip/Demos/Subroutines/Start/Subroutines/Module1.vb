﻿Module Module1

    Sub Main()
        Dim value As String

        value = "Visual Basic"
        For index As Integer = value.Length - 1 To 0 Step -1
            Console.Write(value(index))
        Next
        Console.WriteLine()

        value = "Visual Studio"
        For index As Integer = value.Length - 1 To 0 Step -1
            Console.Write(value(index))
        Next
        Console.WriteLine()

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

End Module
