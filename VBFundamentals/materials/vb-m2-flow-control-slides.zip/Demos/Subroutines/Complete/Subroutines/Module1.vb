﻿Module Module1

    Sub Main()
        Dim value As String

        value = "Visual Basic"
        DisplayReversedString(value)

        value = "Visual Studio"
        DisplayReversedString(value)

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

    Sub DisplayReversedString(value As String)
        For index As Integer = value.Length - 1 To 0 Step -1
            Console.Write(value(index))
        Next
        Console.WriteLine()
    End Sub

End Module
