﻿Module Module1

    Sub Main()
        Dim nums() As Double = {10.5, 20.5, 30.5, 40.5, 50.5}

        For Each value As Double In nums
            Console.WriteLine(value)
        Next

        Console.WriteLine("Done")
        Console.ReadKey()

    End Sub

End Module
