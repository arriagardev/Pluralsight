﻿Module Module1

    Sub Main()
        Dim nums() As Integer = {10, 20, 30}

        Try
            ShowNumbers(nums)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

    Sub ShowNumbers(nums() As Integer)
        For index As Integer = 0 To nums.Length
            Dim value As Integer = nums(index)
            Console.WriteLine(value)
        Next
    End Sub

End Module
