﻿Module Module1

    Sub Main()
        Dim value As String
        Dim reversed As String

        value = "Visual Basic"
        reversed = ReverseString(value)
        Console.WriteLine(reversed)

        value = "Visual Studio"
        reversed = ReverseString(value)
        Console.WriteLine(reversed)

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

    Function ReverseString(value As String) As String
        Dim result As String = ""

        For index As Integer = value.Length - 1 To 0 Step -1
            result += value(index)
        Next

        Return result
    End Function

End Module
