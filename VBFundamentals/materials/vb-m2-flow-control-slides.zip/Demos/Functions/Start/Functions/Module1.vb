﻿Module Module1

    Sub Main()
        Dim value As String
        Dim reversed As String

        value = "Visual Basic"
        reversed = ""
        For index As Integer = value.Length - 1 To 0 Step -1
            reversed += value(index)
        Next
        Console.WriteLine(reversed)

        value = "Visual Studio"
        reversed = ""
        For index As Integer = value.Length - 1 To 0 Step -1
            reversed += value(index)
        Next
        Console.WriteLine(reversed)

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

End Module
