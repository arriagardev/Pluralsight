﻿Module Module1

    Sub Main()
        BuyDrinks(17)
    End Sub

    Sub BuyDrinks(age As Integer)
        If age < 21 Then
            Throw New ArgumentException("Must be 21 or older")
        End If
        ' ...
    End Sub

End Module
