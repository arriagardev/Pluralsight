﻿Module Module1

    Sub Main()
        Dim nums() As Integer = {10, 25, 30, 45, 50, 65}

        For index As Integer = 0 To nums.Length - 1
            Dim value As Integer = nums(index)
            If value = 45 Then
                Continue For
            End If
            Console.WriteLine(value)
        Next

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

End Module
