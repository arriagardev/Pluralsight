﻿Module Module1

    Sub Main()
        Dim age As Integer = 14

        If age <= 2 Then
            Console.WriteLine("Serve milk")
        ElseIf age <= 21 Then
            Console.WriteLine("Serve soda")
        Else
            Console.WriteLine("Serve drink")
        End If

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

End Module
