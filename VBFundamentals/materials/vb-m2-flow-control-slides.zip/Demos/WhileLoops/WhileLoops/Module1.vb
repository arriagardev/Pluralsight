﻿Module Module1

    Sub Main()
        Dim nums() As Integer = {10, 25, 30, 45, 50, 65}

        Dim index As Integer = 0
        Dim value As Integer = nums(index)
        While value < 50
            Console.WriteLine(value)
            index += 1
            value = nums(index)
        End While

        Console.WriteLine("Done")
        Console.ReadKey()
    End Sub

End Module
