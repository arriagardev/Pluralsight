﻿Public Class SetupWorkflow
    Inherits WorkItemBase

End Class
