﻿Public MustInherit Class WorkItemBase

End Class