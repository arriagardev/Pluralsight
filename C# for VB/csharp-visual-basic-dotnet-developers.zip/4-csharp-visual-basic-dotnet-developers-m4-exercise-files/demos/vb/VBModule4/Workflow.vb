﻿'Public Class WorkFlow(Of T)

'End Class

'Public Class WorkFlow(Of T As IDisposable)

'End Class

'Public Class WorkFlow(Of T As {IComparable, IDisposable, Class, New})

'End Class

'Public Class Workflow
'    Public Sub Process(Of T As WorkItemBase)(s As T)

'    End Sub
'End Class