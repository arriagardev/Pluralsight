﻿using System;

namespace CSModule4
{
    public class BasicMathOperations
    {
        public decimal Add(decimal x, decimal y)
        {
            return decimal.Add(x, y);
        }

        public decimal Subtract(decimal x, decimal y)
        {
            return decimal.Subtract(x, y);
        }

        public decimal Multiply(decimal x, decimal y)
        {
            return decimal.Multiply(x, y);
        }

        public decimal Divide(decimal x, decimal y)
        {
            return decimal.Divide(x, y);
        }
    }
}
