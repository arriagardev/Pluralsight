﻿Public Interface IRenderingProvider
    Sub Render()
End Interface
