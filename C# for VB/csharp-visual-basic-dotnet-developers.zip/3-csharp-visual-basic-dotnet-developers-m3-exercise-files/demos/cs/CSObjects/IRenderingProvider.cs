﻿
namespace CSObjects
{
    public interface IRenderingProvider
    {
        void Render();
    }
}
