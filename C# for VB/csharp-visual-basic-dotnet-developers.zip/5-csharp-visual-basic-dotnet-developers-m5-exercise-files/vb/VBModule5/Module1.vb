﻿Module Module1

    Sub Main()

        Dim memory = My.Computer.Info.TotalPhysicalMemory

        Dim myDocumentsPath = My.Computer.FileSystem.SpecialDirectories.MyDocuments



        Dim culture = My.Application.Culture.Name



        Console.ReadLine()

    End Sub

End Module
