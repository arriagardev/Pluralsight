﻿
namespace NETConverter.Domain
{
    public enum CodeConversionTypes
    {
        cs2vbnet,
        vbnet2cs
    }
}
